<?php include('includes/header.php')?>
<?php include('../includes/session.php')?>
<body>
	<div class="pre-loader">
		<div class="pre-loader-box">
			<div class="loader-logo"><img src="../vendors/images/deskapp-logo-svg.png" alt=""></div>
			<div class='loader-progress' id="progress_div">
				<div class='bar' id='bar1'></div>
			</div>
			<div class='percent' id='percent1'>0%</div>
			<div class="loading-text">
				Loading...
			</div>
		</div>
	</div>

	<?php include('includes/navbar.php')?>

	<?php include('includes/right_sidebar.php')?>

	<?php include('includes/left_sidebar.php')?>

    <?php if(isset($_POST['reports'])){?>

	<div class="mobile-menu-overlay"></div>

	<div style="margin-bottom: 0px; margin-top: 0px;" class="main-container">
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>REPORTS</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
									<li class="breadcrumb-item active" aria-current="page">Reports</li>
								</ol>
							</nav>
						</div>
					</div>
				</div>
				<div  style="margin-top: 5px;" class="pd-20 card-box mb-30">

					<div class="wizard-content">
						<form method="post" action="">
							<section>
								<div class="row">
									<div class="col-md-6 col-sm-12">
										<div class="form-group">
											<label>Report Generation Start Date :</label>
											<input name="date_from" type="text" class="form-control date-picker" required="true" autocomplete="off" value="<?php echo $_POST['date_from'] ;?>">
										</div>
									</div>
									<div class="col-md-6 col-sm-12">
										<div class="form-group">
											<label>Report Generation End Date :</label>
											<input name="date_to" type="text" class="form-control date-picker" required="true" autocomplete="off" value="<?php echo $_POST['date_to'] ;?>">
										</div>
									</div>
								</div>
							<div class="row">
									<div class="col-md-6 col-sm-12">
										<div class="form-group">
										</div>
									</div>

									<div class="col-md-6 col-sm-12">
										<div class="form-group">
											<label style="font-size:16px;"><b></b></label>
											<button class="btn btn-primary" name="reports" id="reports" data-toggle="modal">Report&nbsp;Generation</button>
										</div>
									</div>
								</div>
						

							</section>
						</form>
					</div>
				</div>
		</div>
	</div>
	<div style="margin-top: 0px; margin-bottom: 0px;"class="main-container">
	    <div class="card-box mb-30">
				<div style="margin-top: 0px; margin-bottom: 0px;" class="pd-20">
						<h2 class="text-blue h4">REPORT</h2>
					</div>
				<div class="pb-20">
					<table class="data-table table stripe hover nowrap">
						<thead>
							<tr>
								<th class="table-plus datatable-nosort">NAME</th>
								<th>DEPARTMENT</th>
								<th>ROLE</th>
								<th>LEAVE TYPE</th>
								<th>DATE FROM</th>
								<th>DATE TO</th>
								<th class='datatable-nosort'>STATUS</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								
								 <?php 
								    $givendate=date('Y-m-d', strtotime($_POST['date_from']));
								    $givendate1=date('Y-m-d', strtotime($_POST['date_to']));
                                     $sql = "SELECT tblemployees.FirstName,tblemployees.LastName,tblemployees.role,tblemployees.Department,tblleaves.LeaveType,tblleaves.ToDate,tblleaves.FromDate,tblleaves.num_days,tblleaves.apply_status,tblleaves.admin_status,tblemployees.Status from tblleaves join tblemployees on tblleaves.empid=tblemployees.emp_id where ((tblleaves.FromDate>='$givendate' and tblleaves.FromDate<='$givendate1') or (tblleaves.ToDate>='$givendate' and tblleaves.ToDate<='$givendate1') or (tblleaves.FromDate<='$givendate' and tblleaves.ToDate>='$givendate') or (tblleaves.FromDate<='$givendate1' and tblleaves.ToDate>='$givendate1')) and tblemployees.emp_id='$session_id'";
                                    $query = $dbh -> prepare($sql);
                                    $query->execute();
                                    $results=$query->fetchAll(PDO::FETCH_OBJ);
                                    $cnt=1;
                                    if($query->rowCount() > 0)
                                    {
                                    foreach($results as $result)
                                    {               ?>  
                                  <td><?php echo $cnt.' '.htmlentities($result->FirstName).' '.htmlentities($result->LastName);?></td>
                                  <td><?php echo htmlentities($result->Department);?></td>
                                  <td><?php echo htmlentities($result->role);?></td>
								  <td><?php echo htmlentities($result->LeaveType);?></td>
                                  <td><?php echo htmlentities($result->FromDate);?></td>
                                  <td><?php echo htmlentities($result->ToDate);?></td>
                                  <td><?php $a_stats=$result->apply_status;
	                                      $stats=$result->Status;
	                                      $ad_stats=$result->admin_status;?>
									<?php
									if ($stats==1 and $ad_stats==1 and $a_stats!=1): ?>
									   <span style="color: green">Sanctioned</span>
									   <?php
									elseif($a_stats==1): ?>
									   <span style="color: red">Cancelled</span>
									   <?php
									elseif($stats==2 or $ad_stats==2): ?>
									   <span style="color: red">Rejected</span>
									   <?php
									else: ?>
									   <span style="color: violet">Applied</span>
									<?php endif ?></td>
							</tr>
							<?php $cnt++;} }?>  
						</tbody>
					</table>
			   </div>
			</div>

			<?php include('includes/footer.php'); ?>
		</div>
	</div>
    <?php } else {?>
    		<div class="mobile-menu-overlay"></div>

	<div class="main-container">
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>REPORTS</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
									<li class="breadcrumb-item active" aria-current="page">Reports</li>
								</ol>
							</nav>
						</div>
					</div>
				</div>

				<div class="pd-20 card-box mb-30">
					<div class="wizard-content">
						<form method="post" action="">
							<section>
								<div class="row">
									<div class="col-md-6 col-sm-12">
										<div class="form-group">
											<label>Report Generation Start Date :</label>
											<input name="date_from" type="text" class="form-control date-picker" required="true" autocomplete="off">
										</div>
									</div>
									<div class="col-md-6 col-sm-12">
										<div class="form-group">
											<label>Report Generation End Date :</label>
											<input name="date_to" type="text" class="form-control date-picker"  autocomplete="off">
										</div>
									</div>
								</div>
									<div class="row">
									<div class="col-md-6 col-sm-12">
										<div class="form-group">
										</div>
									</div>
									<div class="col-md-4 col-sm-12">
										<div class="form-group">
											<label style="font-size:16px;"><b></b></label>
												<button class="btn btn-primary" name="reports" id="reports" data-toggle="modal">Report&nbsp;Generation</button>
										</div>
									</div>
								</div>
							</section>
						</form>
					</div>
				</div>
			<?php include('includes/footer.php'); ?>		
	</div>
</div>
	<!-- js -->
	<?php }include('includes/scripts.php')?>
</body>
</html>
<?php
	/*if(isset($_POST['apply']))
	{
	$empid=$session_id;
	$leave_type=$_POST['leave_type'];
	$fromdate=date('Y-m-d', strtotime($_POST['date_from']));
	$todate=date('Y-m-d', strtotime($_POST['date_to']));
	$nowdate=date('Y-m-d',strtotime("now"));
	$description=$_POST['description'];  
	$status=1;
	$isread=1;
	$apply_status=0;
	$leave_days=$_POST['leave_days'];
	$datePosting = date("Y-m-d");

	if($fromdate < $nowdate)
    {

    	echo "<script>alert('Start Date should be greater than or equal to Current Date');</script>";
    }
    elseif($todate < $nowdate)
	{
	    echo "<script>alert('End Date should be greater than  Curret Date');</script>";
	  }
	elseif($fromdate > $todate)
	{
	    echo "<script>alert('End Date should be greater than Start Date');</script>";
	  }
	elseif($leave_days <= 0)
	{
	    echo "<script>alert('YOU HAVE EXCEEDED YOUR LEAVE LIMIT. LEAVE APPLICATION FAILED');</script>";
	  }

	else {
		
		$DF = date_create($_POST['date_from']);
		$DT = date_create($_POST['date_to']);

		$diff =  date_diff($DF , $DT );
		$num_days = (1 + $diff->format("%a"));

		$sql="INSERT INTO tblleaves(LeaveType,ToDate,FromDate,Description,Status,IsRead,empid,num_days,PostingDate,apply_status) VALUES(:leave_type,:fromdate,:todate,:description,:status,:isread,:empid,:num_days,:datePosting,:apply_status)";
		$query = $dbh->prepare($sql);
		$query->bindParam(':leave_type',$leave_type,PDO::PARAM_STR);
		$query->bindParam(':fromdate',$fromdate,PDO::PARAM_STR);
		$query->bindParam(':todate',$todate,PDO::PARAM_STR);
		$query->bindParam(':description',$description,PDO::PARAM_STR);
		$query->bindParam(':status',$status,PDO::PARAM_STR);
		$query->bindParam(':isread',$isread,PDO::PARAM_STR);
		$query->bindParam(':apply_status',$apply_status,PDO::PARAM_STR);
		$query->bindParam(':empid',$empid,PDO::PARAM_STR);
		$query->bindParam(':num_days',$num_days,PDO::PARAM_STR);
		$query->bindParam(':datePosting',$datePosting,PDO::PARAM_STR);
		$query->execute();
		$lastInsertId = $dbh->lastInsertId();
		if($lastInsertId)
		{
			echo "<script>alert('Leave Application was successful.');</script>";
			echo "<script type='text/javascript'> document.location = 'leave_history.php'; </script>";
		}
		else 
		{
			echo "<script>alert('Something went wrong. Please try again');</script>";
		}

	}

}*/

?>