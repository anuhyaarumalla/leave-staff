<?php
  include('includes/header.php');
  include('../includes/session.php');
  $db = new mysqli('localhost', 'root','','leave_staff');
  if(isset($_POST['submit'])):
        extract($_POST);
        if($old_password!="" && $password!="" && $confirm_pwd!=""):
            $emp_id =$_SESSION["alogin"];
            $old_pwd=md5(mysqli_real_escape_string($db,$_POST['old_password']));
            $pwd=md5(mysqli_real_escape_string($db,$_POST['password']));
            $c_pwd=md5(mysqli_real_escape_string($db,$_POST['confirm_pwd']));
            if($pwd == $c_pwd):
                if($pwd!=$old_pwd):
              $sql ="SELECT * FROM tblemployees where  password ='$old_pwd' and emp_id='$emp_id'";
                  $query= mysqli_query($conn, $sql);
              $count = mysqli_num_rows($query);
              if($count > 0):
                     $fetch=$db->query("UPDATE `tblemployees` SET `password` = '$pwd' WHERE `emp_id`='$emp_id'");
                     $old_password=''; $password =''; $confirm_pwd = '';
                     $msg_sucess = "Your new password update successfully.";
                  else:
                    $error = "The password you gave is incorrect.";
                  endif;
                else:
                  $error = "Old password new password same Please try again.";
                endif;
            else:
              $error = "New password and confirm password do not matched";
            endif;
        else:
          $error = "Please fil all the fields";
        endif;   
  endif;
?> 


<html>
<head>
  <title>Change password in php mysql code</title>
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<style type="text/css">
.error{
margin-top: 6px;
margin-bottom: 0;
color: #fff;
background-color: #D65C4F;
display: table;
padding: 5px 8px;
font-size: 11px;
font-weight: 600;
line-height: 14px;
  }
  .green{
margin-top: 6px;
margin-bottom: 0;
color: #fff;
background-color: green;
display: table;
padding: 5px 8px;
font-size: 11px;
font-weight: 600;
line-height: 14px;
  }
.one{
  margin-left:40px;
}
.o{
  margin-left:160px;
}
</style>
</head>
<body style="background-color: skyblue">  
  <div class="pre-loader">
        <div class="pre-loader-box">
            <div class="loader-logo"><img src="../vendors/images/deskapp-logo-svg.png" alt=""></div>
            <div class='loader-progress' id="progress_div">
                <div class='bar' id='bar1'></div>
            </div>
            <div class='percent' id='percent1'>0%</div>
            <div class="loading-text">
                Loading...
            </div>
        </div>
    </div>
  <?php include('includes/navbar.php')?>

  <?php include('includes/right_sidebar.php')?>

  <?php include('includes/left_sidebar.php')?>
  <div class="col-md-12">
    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <!-- edgead2 -->
    <ins class="adsbygoogle"
         style="display:inline-block;width:970px;height:90px"
         data-ad-client="ca-pub-9665679251236729"
         data-ad-slot="3549086226"></ins>
    <script>
    (adsbygoogle = window.adsbygoogle || []).push({});
    </script>  
  </div> 


        <div class="modal-dialog">
        <h2 class="o"><b>Change New Password</b></h2>
        <div>       
        <div class="modal-content col-md-10">
        <div class="modal-header">
        <h4 class="modal-title" style="color:red;"><i class="icon-paragraph-justify2"></i> Change New Password</h4>
        </div>
        <form method="post" autocomplete="off" id="password_form">
          <div class="modal-body with-padding">
          <div class="form-group">
            <div class="row">
              <div class="col-sm-10">
                <label>Old Password</label>
                <input type="password" name="old_password" value="<?php echo @$old_password ?>" class="form-control">
              </div>
            </div>
          </div>                             
          <div class="form-group">
            <div class="row">
              <div class="col-sm-10">
                <label>New Password</label>
                <input type="password"  name="password" value="<?php echo @$password ?>" class="form-control">
              </div>
            </div>
          </div>
          <div class="form-group">
          <div class="row">
            <div class="col-sm-10">
              <label>Confirm password</label>
              <input type="password"  name="confirm_pwd" value="<?php echo @$confirm_pwd ?>" class="form-control">
            </div>
          </div>
          </div>         
          </div>
           <div class="<?=(@$msg_sucess=="") ? 'error' : 'green' ; ?>" id="logerror">
             <?php echo @$error; ?><?php echo @$msg_sucess; ?>
            </div> 
          <!-- end Add popup  -->  
          <div class="modal-footer">          
            <input type="submit" id="btn-pwd" name="submit" value="Submit" class="btn btn-primary">            
          </div>
        </form> 

        </div>  
        <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
          <!-- edgead2 -->
          <ins class="adsbygoogle"
               style="display:inline-block;width:970px;height:90px"
               data-ad-client="ca-pub-9665679251236729"
               data-ad-slot="3549086226"></ins>
          <script>
          (adsbygoogle = window.adsbygoogle || []).push({});
          </script>  
        </div> 
        </div>
  <?php include('includes/scripts.php')?>
</body>
</html>
