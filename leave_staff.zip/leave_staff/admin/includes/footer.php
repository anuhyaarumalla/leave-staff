<div class="footer-wrap pd-20 mb-20 card-box">
				RVRJC Leave System
			</div>