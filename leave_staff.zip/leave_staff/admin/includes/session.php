<?php
 session_start(); 
//Check whether the session variable SESS_MEMBER_ID is present or not
if (!isset($_SESSION['alogin']) || (trim($_SESSION['alogin']) == '')) { ?>
<script>
window.location = "../index.php";
</script>
<?php
}

$session_id=$_SESSION['alogin'];
$sql = "SELECT * from tblemployees where emp_id = '$session_id'";
$query = mysqli_query($conn, $sql) or die(mysqli_error());
while ($row = mysqli_fetch_array($query)) {
	$session_depart=$row['Department'];
	$session_name=$row['FirstName']							

?>