<?php if(isset($_POST['hi'])){ ?>
           <audio src= "Aa Andaniki Aa Face Cut Ku Manam Iche Value Anthandi - Dialogue.mp3" id="audio" controls style="display:none;">
<script type="text/javascript">
   document.getElementById('audio').play();
</script>
<?php } ?>
<body>
</script>
<form action="" method="post">
	<input type="submit" name="hi" value="submit">
</form>
</body>