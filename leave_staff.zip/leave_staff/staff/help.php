<?php include('includes/header.php')?>
<html>
<head>
  <title>apply leave</title>
  <link href=".css" rel="stylesheet" type="text/css" />
  <style>
  
  ul {
    list-style-type: none;
    margin-left:0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}
p{
     margin-left:300px;
}

li{
    float: left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
}

/* Change the link color to #111 (black) on hover */
li a:hover {
    background-color: #2E8B57;
}

  </style>

</head>
<body>
<i>
<b>
<ul >
  <li><a href="index.php">Home</a></li>
  <li><a href="change_password.php">Change Password</a></li>
  <li><a href="apply_leave.php">Apply Leave</a></li>
  <li><a href="leave_history.php">Leave History</a></li>
  <li><a href="help.php">Help</a></li>
  <li style="float:right"><a href="../logout.php">Logout</a></li>
  <li style="float:right"><a href="head_profile.php"><?php session_start(); echo "welcome  ".$_SESSION['fname']."";?></a></li>
 
</ul>
</b>
</i>
<p>
<b><h1><font color="black" size="6vm"><i><b>A person who logged in can be able to</b></i></font></h1></b></br>
<b><h4>
~<i>Go to Home Page</i> from <a href="admin_dashboard.php">HOME</a><br>
<br> 
~<i>Change password</i> from <a href="change_password.php">CHANGE PASSWORD</a><br><br> 
~Manage the <i>Staff Details</i> from <a href="staff.php">MANAGE STAFF</a><br><br>
~Go to <i>Apply Leave</i> from <a href="leave_history.php">ALL LEAVES</a><br><br>
~Go to <i>Leave History</i> from <a href="leaves.php">ALL LEAVES</a><br><br>    
~Check the <i>All leaves</i> from <a href="leaves.php">ALL LEAVES</a><br><br> 
~Check the <i>All pending leaves</i> from <a href="pending_leave.php">ALL PENDING LEAVES</a><br><br>
~Check the <i>All Rejected leaves</i> from <a href="rejected_leave.php">ALL REJECTED LEAVES</a><br>
</h4>
</p>
</body>
</html>